package m.ify.taxim.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.core.splashscreen.SplashScreen;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;

import com.google.android.material.button.MaterialButton;

import m.ify.taxim.R;
import m.ify.taxim.Helpers.StateSaver;

public class WelcomeActivity extends AppCompatActivity {

    private SplashScreen splashScreen;
    private MotionLayout motionLayout;
    private MaterialButton continueBtn;
    private StateSaver saver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        splashScreen = SplashScreen.installSplashScreen(this);
//        Full screen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);


        motionLayout = (MotionLayout) findViewById(R.id.motionLayout);
        continueBtn = (MaterialButton) findViewById(R.id.continueBtn);
        saver = new StateSaver(this,"welcome");

        //this will keep only the logo on screen for 1.5s and then start the animation and show the continue button
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                motionLayout.transitionToEnd();
            }
        },1500);

        //We need to check the welcome screen if it is the first time           1:already showed               0:the first time
        if (saver.getState() == 1){
            Intent i = new Intent(WelcomeActivity.this, LoginActivity.class);
            startActivity(i);
            finish();
        }

        //handle the continue click
        continueBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //We need to navigate to the second activity but before that we need to save just to make sure not to repete the welcome screen
                saver.setState(1);
                Intent i = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(i);
                //we need to finish the current activity
                finish();
            }
        });


        splashScreen.setKeepOnScreenCondition(new SplashScreen.KeepOnScreenCondition() {
            @Override
            public boolean shouldKeepOnScreen() {
                //return true to keep splash screen
                return false;
            }
        });

    }
}