package m.ify.taxim.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import m.ify.taxim.Fragments.LoginSignupFragment;
import m.ify.taxim.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (savedInstanceState == null){
            Fragment fragment = new LoginSignupFragment();
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragmentHolder,fragment,"01")
                    .commit();
        }

    }
}