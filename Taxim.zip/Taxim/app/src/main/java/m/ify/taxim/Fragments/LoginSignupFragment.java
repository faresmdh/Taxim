package m.ify.taxim.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.button.MaterialButton;

import m.ify.taxim.R;

public class LoginSignupFragment extends Fragment {

    //XML
    private MaterialButton login,signup;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_login_signup,container,false);

        //XML
        login = (MaterialButton) v.findViewById(R.id.loginBtn);
        signup = (MaterialButton) v.findViewById(R.id.registerBtn);

        //Handle login click
        login.setOnClickListener(view -> {
            Fragment newFragment,oldFragment;
            newFragment = new LoginFragment();
            oldFragment = getActivity().getSupportFragmentManager().findFragmentByTag("01");
            switchFragments(oldFragment,newFragment,"02");
        });

        //Handle signup click
        signup.setOnClickListener(view -> {
            Fragment newFragment,oldFragment;
            newFragment = new SignupFragment();
            oldFragment = getActivity().getSupportFragmentManager().findFragmentByTag("01");
            switchFragments(oldFragment,newFragment,"03");
        });

        return v;
    }

    private void switchFragments(Fragment oldFrag,Fragment newFrag,String tag){
        getActivity().getSupportFragmentManager().beginTransaction()
                .hide(oldFrag)
                .add(R.id.fragmentHolder,newFrag,tag)
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                .addToBackStack(null)
                .commit();
    }

}
