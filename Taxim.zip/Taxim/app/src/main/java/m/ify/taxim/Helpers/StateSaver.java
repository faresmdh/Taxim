package m.ify.taxim.Helpers;

import android.content.Context;
import android.content.SharedPreferences;

public class StateSaver {

    private Context context;
    private String saveName;

    private SharedPreferences sp;

    public StateSaver(Context context, String saveName) {
        this.context = context;
        this.saveName = saveName;
        sp = context.getSharedPreferences(saveName,Context.MODE_PRIVATE);
    }

    public void setState(int value){

        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("key",value);
        editor.apply();

    }

    public int getState(){
        return sp.getInt("key",0);
    }
}
